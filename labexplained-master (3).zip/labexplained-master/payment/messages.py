PAYMENT_SESSION_MESSAGES = {
    'successful': 'Payment successful; Verification in progress. Please wait.',
    'verified': 'Payment already verified; You can start using the upgraded version.',
    'error': 'Payment error; If you paid already please wait for the payment to verify.',
    'cancelled': 'Payment cancelled; If you paid already, connect to the support team and try again.',
    'open': "Your checkout is underway; We're getting ready to process your payment.",
    'started': "Your payment process has begun, but we haven't received payment yet.",
    'complete': "Checkout is complete, and We're finalizing your payment verification securely.",
    'expired': "Oops, your checkout session has timed out. Please start again to complete.",
    'notfound': "Payment session not found!"
}
