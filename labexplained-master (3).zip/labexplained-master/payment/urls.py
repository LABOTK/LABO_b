# urls.py

from django.urls import path

from payment import views
from payment.views import PaymentSessionStarted

urlpatterns = [
    path('plans', views.payment_plans, name='payment_plans'),
    path('session/started/', PaymentSessionStarted.as_view(), name='payment_session_started'),
    path('session/successful', views.payment_session_successful, name='payment_session_successful'),
    path('session/cancelled', views.payment_session_cancelled, name='payment_session_cancelled'),
    path('stripe/webhook', views.stripe_webhook, name='payment_stripe_webhook'),
]
