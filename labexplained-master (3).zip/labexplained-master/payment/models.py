from django.db import models
import uuid

from account.models import UserData
from lib.choices import (
    PaymentIntervalType, PaymentCurrencyType,
    PaymentStatusType, PaymentSessionStatusType, PaymentProviderType
)


class PlanFeature(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(unique=True, max_length=100)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name}"


class ProductPlan(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    product_id = models.CharField(max_length=255, unique=True, blank=False)
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=10, choices=PaymentCurrencyType.choices)
    interval = models.CharField(max_length=10, choices=PaymentIntervalType.choices)
    is_active = models.BooleanField(default=True)  # make it false on prod
    features = models.ManyToManyField(PlanFeature, related_name='plans')
    provider = models.CharField(max_length=40, choices=PaymentProviderType.choices,
                                default=PaymentProviderType.stripe, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} - {self.price} - {self.interval}"

    class Meta:
        ordering = ["name", 'interval']
        unique_together = ('name', 'interval')


class UserPayment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(UserData, on_delete=models.PROTECT)
    plan = models.ForeignKey(ProductPlan, on_delete=models.PROTECT)
    is_paid = models.BooleanField(default=False)
    session_id = models.CharField(max_length=500, unique=True, null=True, blank=True)
    session_status = models.CharField(max_length=255, choices=PaymentSessionStatusType.choices)
    payment_status = models.CharField(max_length=255, choices=PaymentStatusType.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.email} - {self.session_status} - {self.payment_status}"

