import json

from django.core.management.base import BaseCommand

from payment.models import ProductPlan, PlanFeature

PAYMENT_PLANS_JSON_FILE_PATH = 'data/payment_plans_data.json'
PAYMENT_FEATURES_JSON_FILE_PATH = 'data/payment_plans_features.json'


class Command(BaseCommand):
    help = 'Load initial payment plans data from JSON file'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Drop all payment plans and load data again')

    def handle(self, *args, **options):

        force_load = options['force']

        existing_plans = ProductPlan.objects.exists()

        if existing_plans and not force_load:
            self.stdout.write(self.style.WARNING('Payment Plans data already exists. Use --force to re-add.'))
            return

        if force_load:
            self.stdout.write(self.style.WARNING('Dropping all existing payment plans...'))
            ProductPlan.objects.all().delete()
            PlanFeature.objects.all().delete()

        with open(PAYMENT_PLANS_JSON_FILE_PATH, 'r') as json_file:
            plans_data = json.load(json_file)

        with open(PAYMENT_FEATURES_JSON_FILE_PATH, 'r') as json_file:
            plans_features = json.load(json_file)

        # adding features
        for feature in plans_features:
            PlanFeature.objects.update_or_create(**feature)

        # adding plans
        for product_plan in plans_data:
            plan_feature = product_plan.pop('features')
            obj, created = ProductPlan.objects.update_or_create(**product_plan)
            # Retrieve the selected features and Associate to Plan
            selected_features = PlanFeature.objects.filter(name__in=plan_feature)
            obj.features.set(selected_features)

        self.stdout.write(self.style.SUCCESS('Payment plans data loaded successfully'))
