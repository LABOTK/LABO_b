from rest_framework import serializers
from payment.models import ProductPlan, PlanFeature


class PlanFeatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanFeature
        fields = ['name', 'text']


class PlanSerializer(serializers.ModelSerializer):
    features = PlanFeatureSerializer(many=True, read_only=True)

    class Meta:
        model = ProductPlan
        fields = ['id', 'name', 'price', 'interval', 'features']
