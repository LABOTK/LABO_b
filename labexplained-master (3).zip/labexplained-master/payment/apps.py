from django.apps import AppConfig


class PaymentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'payment'

    def ready(self):
        from django.core.management import call_command
        call_command("add_payment_plans")

        # call_command('add_payment_plans', force=True)
