from django import forms
from django.contrib import admin
from payment.models import ProductPlan, PlanFeature


class PlanAdminForm(forms.ModelForm):
    class Meta:
        model = ProductPlan
        fields = '__all__'

    features = forms.ModelMultipleChoiceField(
        queryset=PlanFeature.objects.all(),
        widget=forms.CheckboxSelectMultiple,
    )


class PlanAdmin(admin.ModelAdmin):
    form = PlanAdminForm


admin.site.register(ProductPlan, PlanAdmin)
