import stripe
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.decorators.csrf import csrf_exempt
from loguru import logger
from rest_framework import status
from rest_framework.decorators import permission_classes, authentication_classes, api_view
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from backend import settings
from lib.choices import PaymentSessionStatusType, PaymentStatusType
from payment import messages
from payment.models import ProductPlan, UserPayment
from payment.serializers import PlanSerializer


@csrf_exempt
@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def payment_plans(request):
    interval = request.data.get('interval')
    if interval:
        # payment plans information
        plans = ProductPlan.objects.filter(interval=interval)
        serializer = PlanSerializer(plans, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    # returning error
    return Response({"error": f"interval:{interval} not found."}, status=status.HTTP_400_BAD_REQUEST)


@permission_classes([IsAuthenticated])
class PaymentSessionStarted(APIView):

    def post(self, request):
        user = request.user
        plan_id = request.data.get('plan_id')

        logger.info(f"{user.email} - payment session for plan: {plan_id}")

        try:
            user_payments = UserPayment.objects.filter(user=user).exclude(
                session_status=PaymentSessionStatusType.cancelled,
                payment_status=PaymentStatusType.unpaid
            )
            if user_payments.exists():
                latest_payment = user_payments.latest('created_at')
                return Response(
                    {'error': messages.PAYMENT_SESSION_MESSAGES[latest_payment.session_status]},
                    status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            logger.error(f'{user.email}: {e}')
            return Response(
                {'error': 'Sorry, cannot process payment at this moment!'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # get payment plan information
            plan_obj = ProductPlan.objects.get(id=plan_id)
        except ProductPlan.DoesNotExist:
            return Response({'error': 'Selected plan not found!'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # creating new payment session
            user_payment = UserPayment.objects.create(
                user=user,
                payment_status='unpaid',
                session_status='started',
                plan=plan_obj
            )
        except Exception as e:
            logger.error(e)
            return Response(
                {
                    'error': f'Failed to Create {plan_obj.provider.title()} payment session for {user.email}!'
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # creating stripe session
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[
                    {
                        'price': plan_obj.product_id,
                        'quantity': 1,
                    },
                ],
                mode='subscription',
                success_url=settings.LAB_BACKEND_URL+'/api/payment/session/successful?session_id={CHECKOUT_SESSION_ID}',
                cancel_url=settings.LAB_BACKEND_URL + '/api/payment/session/cancelled?session_id={CHECKOUT_SESSION_ID}',
                customer_email=user.email,
            )

            # save payment session_id
            user_payment.session_id = session.id
            user_payment.save()
            logger.info(f'{user_payment.user.email} - redirected to checkout page.')

        except Exception as e:
            logger.error(e)
            return Response(
                {
                    'error': f'Failed to Start Payment on {plan_obj.provider.title()}!'
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        # redirecting to stripe payment checkout
        return Response({'redirect': session.url})


@csrf_exempt
@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def payment_session_successful(request):
    session_id = request.GET.get('session_id')

    try:
        # Get the user payment from session_id
        payment_obj = UserPayment.objects.get(session_id=session_id)
    except UserPayment.DoesNotExist:
        return Response({'error': 'Payment session not found!'}, status=status.HTTP_400_BAD_REQUEST)

    redirect_url = f'{settings.LAB_FRONTEND_URL}/payment/successful'

    # check if already marked as successful or verified payment
    if payment_obj.session_status in [PaymentSessionStatusType.successful, PaymentSessionStatusType.verified]:
        return redirect(f'{redirect_url}?email={payment_obj.user.email}'
                        f'&details={messages.PAYMENT_SESSION_MESSAGES[payment_obj.session_status]}')

    try:
        # retrieve payment session information
        session = stripe.checkout.Session.retrieve(payment_obj.session_id)
        # update session status

        if session.payment_status == PaymentStatusType.paid:
            payment_obj.session_status = PaymentSessionStatusType.successful
            payment_obj.payment_status = PaymentStatusType.paid
            payment_obj.is_paid = True
        else:
            payment_obj.session_status = session.status

        # save latest session status
        payment_obj.save()

        # for response message
        session_status = payment_obj.session_status

    except Exception as e:
        logger.error(f'Error {e}')
        session_status = 'error'
        redirect_url = f'{settings.LAB_FRONTEND_URL}/payment/error'

    # redirect back url
    details = messages.PAYMENT_SESSION_MESSAGES[session_status]
    logger.info(f'{payment_obj.user.email} - {details}')
    return redirect(f'{redirect_url}?email={payment_obj.user.email}&details={details}')


@csrf_exempt
@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def payment_session_cancelled(request):
    session_id = request.GET.get('session_id')
    redirect_url = f'{settings.LAB_FRONTEND_URL}/payment/cancelled'

    try:
        payment_obj = UserPayment.objects.get(session_id=session_id)
        session_status = payment_obj.session_status
    except UserPayment.DoesNotExist:
        session_status = 'notfound'
        payment_obj = None

    skip_session_check = [PaymentSessionStatusType.successful, PaymentSessionStatusType.verified,
                          PaymentSessionStatusType.complete]

    # if payment is already marked as skip_session_check then do not proceed
    if payment_obj and payment_obj.session_status not in skip_session_check:
        try:
            # retrieve payment session information
            session = stripe.checkout.Session.retrieve(payment_obj.session_id)
            # mark session as canceled
            if session.payment_status != PaymentStatusType.paid:
                payment_obj.session_status = PaymentSessionStatusType.cancelled
            else:
                payment_obj.session_status = session.status

            # save latest session status
            payment_obj.save()

            # for response message
            session_status = payment_obj.session_status

        except Exception as e:
            logger.error(f'Error {e}')
            # mark session as error
            session_status = 'error'
            redirect_url = f'{settings.LAB_FRONTEND_URL}/payment/error'

    else:
        logger.warning(
            f'{payment_obj.user.email} -  Tried to cancel with status already in: {payment_obj.session_status}')

    # redirect back url
    details = messages.PAYMENT_SESSION_MESSAGES[session_status]
    logger.info(f'{payment_obj.user.email} - {details}')
    return redirect(f'{redirect_url}?email={payment_obj.user.email}&details={details}')


@csrf_exempt
@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def stripe_webhook(request):
    try:
        payload = request.body
        signature_header = request.META['HTTP_STRIPE_SIGNATURE']
    except Exception as e:
        err_msg = f'Webhook request is Invalid! \n{e}'
        logger.error(err_msg)
        return HttpResponse(err_msg, status=status.HTTP_400_BAD_REQUEST)

    try:
        # get the signature and verify hook trigger
        event = stripe.Webhook.construct_event(
            payload, signature_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except Exception as e:
        err_msg = f'Webhook construct event failed: \n{e}'
        logger.error(err_msg)
        return HttpResponse(err_msg, status=status.HTTP_400_BAD_REQUEST)

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        session_id = session.get('id', None)

        try:
            user_payment = UserPayment.objects.get(session_id=session_id)
        except UserPayment.DoesNotExist as e:
            err_msg = f'User Payment session not found: \n{e}'
            logger.error(err_msg)
            return HttpResponse(err_msg, status=status.HTTP_400_BAD_REQUEST)

        # marke payment as verified
        user_payment.is_paid = True
        user_payment.payment_status = PaymentStatusType.verified
        user_payment.session_status = PaymentSessionStatusType.verified
        user_payment.save()

        logger.info(f"{user_payment.user.email} - Payment verified.")
    else:
        logger.debug(f"Stripe hook event type is not handled: {event['type']}")

    return HttpResponse(status=status.HTTP_200_OK)
