import os

from loguru import logger

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception as e:
    logger.error(f"{e} \nFailed to load .env")


ALLOWED_ENVIRONMENTS = ['LOCAL', 'STAGING', 'MASTER']


def get_env_value(key, default=None):
    djenv = (os.getenv('ENVIRONMENT') or '').upper()
    if not djenv:
        raise RuntimeError(f"App Environment is not defined. Please set it to one of {ALLOWED_ENVIRONMENTS}")

    if djenv not in ALLOWED_ENVIRONMENTS:
        raise RuntimeError(f"Invalid DJENV value: {djenv}. Please set it to one of {ALLOWED_ENVIRONMENTS}.")

    env_key = f'{djenv}_{key}'
    if env_value := os.getenv(env_key):
        logger.debug(f'found: {env_key}={env_value}')
        return env_value

    if default:
        logger.debug(f'default: {env_key}={default}')
        return default

    raise RuntimeError(f"Environment variable key:'{key}' for env:'{djenv}' is not defined or empty.")
