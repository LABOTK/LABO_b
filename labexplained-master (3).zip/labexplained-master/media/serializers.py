from rest_framework import serializers

from media.models import File


class FilesSerializer(serializers.ModelSerializer):
    class Meta:
        model = File
        fields = "token"


class UploadPdfSerializer(serializers.Serializer):
    file = serializers.FileField()
    name = serializers.CharField(required=False, max_length=255)

    def validate_name(self, value):
        return value[:255] if value else ''
