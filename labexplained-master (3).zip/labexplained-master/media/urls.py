from django.urls import path

from media.views import UploadFileView, MediaFileView

urlpatterns = [
    path("file/<str:url_token>", MediaFileView.as_view(), name="media_file"),
    path("file/upload/", UploadFileView.as_view(), name="upload_file"),
]
