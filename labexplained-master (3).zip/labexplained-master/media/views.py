import uuid

import PyPDF2
import loguru
from django.core.files.storage import default_storage
from django.http import FileResponse, JsonResponse
from rest_framework import status
from rest_framework.decorators import (
    authentication_classes,
    permission_classes,
)
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from lib.common import generate_jwt_file_token, read_pdf_text, get_media_public_url
from lib.config import MAX_PDF_FILE_SIZE
from media.models import File
from media.serializers import UploadPdfSerializer


# Create your views here.
@authentication_classes([])
@permission_classes([AllowAny])
class MediaFileView(APIView):

    def get(self, request, url_token):
        try:
            file = File.objects.get(token=url_token)
            file_path = file.file_path
        except File.DoesNotExist:
            return Response({"error": "Invalid media File access token!"}, status=404)

        if not default_storage.exists(file_path):
            return Response({"error": "File does not exists"}, status=400)

        return FileResponse(default_storage.open(file_path))


class UploadFileView(APIView):
    parser_classes = (MultiPartParser,)

    @permission_classes([IsAuthenticated])
    def post(self, request):
        user = request.user
        serializer = UploadPdfSerializer(data=request.data)
        if serializer.is_valid():
            pdf_file = serializer.validated_data["file"]
            given_name = serializer.validated_data["name"]

            # Check file size
            if pdf_file.size > MAX_PDF_FILE_SIZE:
                return Response(
                    {
                        "error": f"File size exceeds the maximum limit. {MAX_PDF_FILE_SIZE}"
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Check file type using extension
            if not pdf_file.name.lower().endswith('.pdf'):
                return Response(
                    {"error": "Invalid file format. Only PDF files are allowed."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Validate PDF content
            try:
                pdf_reader = PyPDF2.PdfReader(pdf_file)
                if len(pdf_reader.pages) < 1:
                    return Response(
                        {"error": "Invalid PDF file. The PDF has no pages."},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                # Read the text from the PDF file
                pdf_text = read_pdf_text(pdf_file)
                if not pdf_text:
                    return Response(
                        {"error": "Failed to extract text from the PDF file."}, status=status.HTTP_400_BAD_REQUEST
                    )

            except Exception as e:
                loguru.logger.error(e)
                return Response(
                    {"error": "Invalid PDF file."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Save file
            unique_id = str(uuid.uuid4())
            file_name = f"pdf/{user.id}/{unique_id}.pdf"
            saved_path = default_storage.save(file_name, pdf_file)

            # Check saved file
            if not default_storage.exists(saved_path):
                return Response({"error": "Failed to save PDF file."}, status=status.HTTP_400_BAD_REQUEST)

            # Get file token url
            file_token = generate_jwt_file_token(saved_path, user.id)

            # Save Record
            File.objects.create(name=given_name, token=file_token, file_path=saved_path, user=user)

            # Creating response
            response = {
                "file": get_media_public_url(file_token),
                "file_token": file_token,
            }

            # Return the file as the response
            return JsonResponse(response, content_type="application/json", status=status.HTTP_200_OK)
        else:
            return Response({'error': 'No file was submitted.'}, status=status.HTTP_400_BAD_REQUEST)
