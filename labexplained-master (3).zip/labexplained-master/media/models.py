import uuid

from django.db import models

from account.models import UserData


# Create your models here.


class File(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, blank=True)
    token = models.TextField(unique=True, editable=False)
    user = models.ForeignKey(UserData, on_delete=models.CASCADE)
    file_path = models.CharField(blank=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
