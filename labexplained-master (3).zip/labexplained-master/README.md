```shell

# install git
sudo yum install git

# install docker
sudo yum install -y docker

# Remove docker containers
sudo docker stop $(sudo docker ps -aq)
sudo docker rm $(sudo docker ps -aq)
sudo docker volume rm $(sudo docker volume ls -q)
sudo docker rmi $(sudo docker images -aq)
sudo docker system prune -a --volumes


git pull origin master

docker build -t labexplained/lab-frontend:latest .


docker pull labexplained/lab-frontend:latest
docker-compose up -d --build
docker exec -it backend python manage.py migrate

docker exec -it backend python manage.py createsuperuser --email rana@test.com --password 1234

```

docker builder prune

# local settings


### clear docker
```shell

docker stop $(docker ps -aq)
docker rm $(docker ps -aq)
docker volume prune
docker network prune
docker rmi $(docker images -q)
docker image prune
docker system prune -a

```

# adding default values

```shell
python manage.py add_prompts
python manage.py add_language_models
```


# AWS Image Create-Push

```shell
docker build -t backend:staging .
docker tag backend:staging 405526781775.dkr.ecr.ca-central-1.amazonaws.com/backend:staging
aws ecr get-login-password --region ca-central-1 | docker login --username AWS --password-stdin 405526781775.dkr.ecr.ca-central-1.amazonaws.com
docker push 405526781775.dkr.ecr.ca-central-1.amazonaws.com/backend:staging
```


# build postgresql server on local

## docker create postgresql server
```shell
docker-compose up -d --build postgres
```

## docker local build app
```shell
docker build --build-arg REACT_APP_BACKEND_URL=http://localhost:8000 --build-arg ENVIRONMENT=local -t labexplained:local .
```
