from typing import List

import openai
from loguru import logger

from backend import settings

openai.api_key = settings.OPENAI_API_KEY
openai.organization = settings.OPENAI_ORG_ID


class OpenAiHelper:
    max_retries = 3
    model_id = "gpt-3.5-turbo-16k"

    @classmethod
    def _create_message(cls, text, knowledge):
        return [{
            "role": 'system',
            "content": "You are a chatbot that will only generate response form the provided knowledge,"
                       "if not found in knowledge then as them to connect to the chatbot owner,"
                       "and response in friendly tone, and continue the conversation."
        }, {
            "role": 'system',
            "content": f'ALL SYSTEM COMPLETE KNOWLEDGE IS THIS: \n{knowledge} '
        }, {
            "role": 'user',
            "content": 'ONLY WRITE ANSWER RESPONSE FROM SYSTEM KNOWLEDGE.'
        }, {
            "role": 'user',
            "content": f'Answer this: \n{text} '
        }]

    @classmethod
    def _request_openai(cls, message: List):
        # loop and retry to get the response
        for _ in range(cls.max_retries):
            try:
                response = openai.ChatCompletion.create(
                    model=cls.model_id, max_tokens=5000, temperature=1.2, messages=message
                )
                return response.choices[0].message.content
            except Exception as e:
                logger.error(f"Error: while creating response: {e}")

    @classmethod
    def process(cls, text, knowledge):
        answer = cls._request_openai(message=cls._create_message(text, knowledge))
        return answer
