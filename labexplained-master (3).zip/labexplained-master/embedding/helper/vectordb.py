import os
import re
import uuid
from typing import List

import chromadb
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from loguru import logger

from backend import settings
from embedding.models import VectorModel
from media.models import File


class EmbeddingFunctionSingleton:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(EmbeddingFunctionSingleton, cls).__new__(cls)
            logger.debug('creating embedding function!')

            cls._instance.var_ef = OpenAIEmbeddingFunction(
                model_name="text-embedding-ada-002",
                api_key=settings.OPENAI_API_KEY,
                organization_id=settings.OPENAI_ORG_ID,
            )
            logger.success('embedding function - openai - created')

        return cls._instance


class VectorDatabaseHelper:
    base_dir = f'temp/'
    _instance_ef = EmbeddingFunctionSingleton()
    _chunk_size = 1000
    _overlap = int(_chunk_size * 0.1)  # 10%

    # ----------------------------------------------------------------

    @classmethod
    def _get_chromadb_client(cls, user_id):
        location = os.path.join(cls.base_dir, f'vector/{user_id}')
        # create new persistent connection
        try:
            logger.debug(f'Creating new vector database client at {location}')
            return chromadb.PersistentClient(path=location)
        except Exception as e:
            logger.error(e)
            raise e

    # ----------------------------------------------------------------

    @classmethod
    def _get_file_collection(cls, user_id, file_id, create_new=True):
        # get db connection and connect to database
        db_client = cls._get_chromadb_client(user_id)
        logger.debug(f'collections list count: {len(db_client.list_collections())}')
        created = False

        # create or get collection
        if create_new:
            collection = db_client.get_or_create_collection(
                name=str(file_id),
                embedding_function=cls._instance_ef.var_ef,
                metadata={"hnsw:space": "cosine"}
            )
            created = True
        else:
            try:
                collection = db_client.get_collection(
                    name=str(file_id),
                    embedding_function=cls._instance_ef.var_ef,
                )
            except Exception as e:
                logger.error(e)
                collection = None

        return db_client, collection, created

    # ----------------------------------------------------------------

    @classmethod
    def _delete_collection(cls, db_client, file_id):
        db_client.delete_collection(name=file_id)

    # ----------------------------------------------------------------

    @classmethod
    def _load_document_text(cls, reader):

        # loaded document data
        textlist = []
        for i, page in enumerate(reader.pages):
            page_number = i
            page_content = re.sub(r'\s+', ' ', page.extract_text().replace('\n', ' ')).lower()
            # create chunks for each page
            for start in range(0, len(page_content), cls._chunk_size - cls._overlap):
                end = start + cls._chunk_size
                chunk = page_content[start:end]

                textlist.append({
                    'page_num': page_number,
                    'page_content': chunk,
                })

        return textlist

    # ----------------------------------------------------------------

    @classmethod
    def _insert_collection_data(cls, db_client, collection, file_id, metadata_list, document_list, index_list):
        # adding list to collection
        try:
            collection.add(documents=document_list, metadatas=metadata_list, ids=index_list)
        except Exception as e:
            logger.error(e)
            # raise exception delete index from collection
            cls._delete_collection(db_client, file_id)
            raise e

    # ----------------------------------------------------------------

    @classmethod
    def _create_metadata_list(cls, user_id, file_id, pdf_textlist):
        return [
            {
                'page_num': text.get('page_num', 0),
                'user_id': user_id,
                'file_id': file_id,
            }
            for text in pdf_textlist
        ]

    @classmethod
    def _create_index_list(cls, pdf_textlist):
        return [str(uuid.uuid4()) for _ in range(len(pdf_textlist))]

    @classmethod
    def _create_document_list(cls, pdf_textlist):
        return [text.get('page_content') for text in pdf_textlist]

    # ----------------------------------------------------------------
    # Public Functions
    # ----------------------------------------------------------------

    @classmethod
    def similarity_search(cls, file_obj: File, query_texts: List, n_results: int = 2):

        user_id = str(file_obj.user.id)
        file_id = str(file_obj.id)

        logger.info(f"File: {file_id}, performing similarity search")

        _, collection = cls._get_file_collection(user_id, file_id)

        query_results = collection.query(
            query_texts=query_texts,
            n_results=n_results,
            where={"file_id": file_id},
        )

        knowledge_textlist = []
        for document in query_results.get('documents', []):
            knowledge_text = "\n".join([text.replace('\n------\n', ' ') for text in document])
            knowledge_textlist.append(knowledge_text if knowledge_text else 'no knowledge found')

        return knowledge_textlist

    @classmethod
    def delete_document(cls, file_obj: File):
        try:
            vector_obj = VectorModel.objects.get(id=file_obj.id, file=file_obj)

            user_id = str(vector_obj.file.user.id)
            file_id = str(vector_obj.file.id)

            db_client, collection, _ = cls._get_file_collection(user_id, file_id, create_new=False)

            if collection:
                cls._delete_collection(db_client, file_id)

            vector_obj.is_deleted = True
            vector_obj.save()

        except Exception as e:
            logger.error(e)
            raise e

    @classmethod
    def process_document(cls, file_obj: File, file_reader):
        try:
            vector_obj, created = VectorModel.objects.get_or_create(id=file_obj.id, file=file_obj)

            user_id = str(vector_obj.file.user.id)
            file_id = str(vector_obj.file.id)

            db_client, collection, created = cls._get_file_collection(user_id, file_id)

            if created:
                # extract text from pdf file
                pdf_textlist = cls._load_document_text(file_reader)

                # creating list to add in collection
                metadata_list = cls._create_metadata_list(user_id, file_id, pdf_textlist)
                document_list = cls._create_document_list(pdf_textlist)
                index_list = cls._create_index_list(pdf_textlist)

                # inserting data to collection
                cls._insert_collection_data(db_client, collection, file_id, metadata_list, document_list, index_list)

                # update to latest index and metadata
                vector_obj.index_list = index_list
                vector_obj.metadata_list = metadata_list

            # save vector model object
            vector_obj.is_processed = True
            vector_obj.save()

        except Exception as e:
            logger.error(e)
            raise e
