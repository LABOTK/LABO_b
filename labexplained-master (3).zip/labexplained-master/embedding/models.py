import uuid

from django.db import models

from media.models import File


# Create your models here.

class VectorModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    file = models.OneToOneField(File, on_delete=models.PROTECT)
    index_list = models.JSONField(default=list)
    metadata_list = models.JSONField(default=list)
    is_processed = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.id)