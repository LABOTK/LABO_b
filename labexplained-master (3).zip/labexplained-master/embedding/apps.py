from django.apps import AppConfig


class EmbeddingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'embedding'
