# Register your models here.
from django.contrib import admin

from account.models import UserData
from media.models import File
from payment.models import PlanFeature, UserPayment
from processor.models import Podcast, Prompt, LanguageModel

admin.site.register(UserData)
admin.site.register(Podcast)
admin.site.register(Prompt)
admin.site.register(LanguageModel)
admin.site.register(File)
admin.site.register(PlanFeature)
admin.site.register(UserPayment)
