EMAIL_VERIFY_MESSAGES = {
    'successful':  "Email verified successfully!",
    'verified': "Email already verified!",
    'error': "Invalid verification token!",
    'expired': "Verification token has expired!",
    'notfound': "Verification token not found!"
}
