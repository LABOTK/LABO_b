from django.urls import path

from .views import (
    RegisterView,
    VerifyEmailView,
    ForgotPasswordView,
    ResetPasswordView, CustomTokenObtainPairView, CustomTokenRefreshView, ProfileView,
)

urlpatterns = [
    # with auth
    path("login/", CustomTokenObtainPairView.as_view(), name="custom_token_obtain_pair"),
    path("login/refresh/", CustomTokenRefreshView.as_view(), name="custom_token_refresh"),
    # with no auth
    path("register/", RegisterView.as_view(), name="sign_up"),
    path("forgot/password/", ForgotPasswordView.as_view(), name="forgot_password"),
    # with token and no auth
    path("verify/email/", VerifyEmailView.as_view(), name="verify_email"),
    path("reset/password/", ResetPasswordView.as_view(), name="reset_password"),
    # with auth
    path("profile/", ProfileView.as_view(), name="user_profile"),
]
