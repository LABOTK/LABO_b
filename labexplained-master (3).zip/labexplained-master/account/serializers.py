from django.conf import settings
from rest_framework import serializers

from lib.common import generate_jwt_user_token
from .models import UserData, VerificationToken


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserData
        fields = ["email", "password"]

    def create(self, validated_data):
        user = UserData.objects.create(email=validated_data['email'])
        user.set_password(validated_data['password'])
        user.save()

        # Generate verification token and save it in the user object
        token = generate_jwt_user_token(user.id)
        VerificationToken.objects.create(user=user, token=token, type='email_verification')

        # Send verification email
        verify_url = f'{settings.LAB_FRONTEND_URL}/verify/email/{token}'

        subject = f'Verify Your Email: {user.email}'
        message = f'Hi {user.first_name},\nPlease click on the link below to verify your email:\n{verify_url}'

        # logger.info(verify_url)

        # if send_mail_gmail(subject, message, user.email):
        #     return user
        # else:
        #     # Handle the case when the email fails to send
        #     raise serializers.ValidationError('Failed to send verification email.')

        return user


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserData
        fields = ('email', 'first_name', 'last_name', 'is_verified')
