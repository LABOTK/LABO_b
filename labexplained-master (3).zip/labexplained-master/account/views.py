from django.conf import settings
from django.db import transaction
from django.utils import timezone
from loguru import logger
from rest_framework import status
from rest_framework.decorators import authentication_classes, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

# view for registering users
from account.authentication import CustomJWTAuthentication
from account.helper.account_type import get_user_subscription_type
from account.helper.register import AccountRegisterHelper
from account.models import VerificationToken, UserData
from account.serializers import UserSerializer
from lib.common import generate_jwt_user_token, get_serializer_error
from lib.config import (
    PASSWORD_RESET_INTERVAL_THRESHOLD_MINUTES,
    PASSWORD_RESET_TRIES_THRESHOLD,
)


class CustomTokenObtainPairView(TokenObtainPairView):
    authentication_classes = [CustomJWTAuthentication]


class CustomTokenRefreshView(TokenRefreshView):
    authentication_classes = [CustomJWTAuthentication]


@authentication_classes([])
@permission_classes([AllowAny])
class RegisterView(APIView):
    @transaction.atomic
    def post(self, request):
        try:
            return AccountRegisterHelper.create_user(request)
        except Exception as e:
            logger.error(e)
            return Response(
                {'error': 'Failed to process account register request!', 'details': str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )


@authentication_classes([])
@permission_classes([AllowAny])
class VerifyEmailView(APIView):
    @staticmethod
    def post(request):

        try:
            verify_token = request.data.get("verify_token")
            verification_token = VerificationToken.objects.get(token=verify_token).exists()

            if verification_token.exists():
                return Response({"error": "Verification token not found!"}, status=status.HTTP_400_BAD_REQUEST)

            if verification_token.has_expired():
                # verification_token.delete()
                return Response({"error": "Verification token has expired!"},status=status.HTTP_400_BAD_REQUEST)

            user = verification_token.user
            if user.is_verified:
                return Response({"details": "Email already verified!"}, status=status.HTTP_200_OK)

            # if not verified then
            user.is_verified = True
            user.is_active = True
            user.save()

            # update verification token
            verification_token.is_verified = True
            verification_token.save()

            return Response({"details": "Email verified successfully!"}, status=status.HTTP_200_OK)

        except Exception as e:
            logger.error(e)
            return Response({"error": "Invalid verification token!"},status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([AllowAny])
class ForgotPasswordView(APIView):
    def post(self, request):
        email = request.data.get("email")

        if user := UserData.objects.filter(email=email).first():
            # Calculate the time threshold (30 minutes ago)
            time_threshold = timezone.now() - timezone.timedelta(
                minutes=PASSWORD_RESET_INTERVAL_THRESHOLD_MINUTES
            )

            # Filter tokens created in the last 30 minutes
            recent_tokens = VerificationToken.objects.filter(
                user=user, type="reset_password", created_at__gte=time_threshold
            )

            if recent_tokens.count() >= PASSWORD_RESET_TRIES_THRESHOLD:
                return Response(
                    {
                        "message": "Exceeded maximum reset attempts. Please try again later."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Create the token
            token = generate_jwt_user_token(user.id)
            token_obj = VerificationToken.objects.create(
                user=user, token=token, type="reset_password"
            )
            token_obj.save()

            # Create a verification link
            verify_url = f"{settings.LAB_FRONTEND_URL}/reset/password/{token}"

            # Send the verification link to the user's email
            subject = "Reset Password"
            message = f"Click the following link to reset your password: {verify_url}"

            # logger.info(verify_url)

            # if not send_mail_gmail(subject, message, user.email):
            #     # Handle the case when the email fails to send
            #     logger.error('Failed to send verification email.')

            # Always return success to prevent email harvesting
            return Response(
                {"message": "Email sent successfully!"}, status=status.HTTP_200_OK
            )
        else:
            return Response(
                {"error": "User with this email not found!"},
                status=status.HTTP_400_BAD_REQUEST,
            )


@authentication_classes([])
@permission_classes([AllowAny])
class ResetPasswordView(APIView):
    def post(self, request):
        try:
            reset_token = request.data.get("reset_token")
            verification_token = VerificationToken.objects.get(token=reset_token)

            if verification_token.has_expired():
                # verification_token.delete()
                return Response(
                    {"error": "Reset token has expired!"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            user = verification_token.user
            new_password = request.data.get("new_password")

            if not new_password:
                return Response(
                    {"error": "New Password not found!"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # reset the password
            user.set_password(new_password)
            user.save()

            # Mark the token as verified to prevent reuse
            verification_token.is_verified = True
            verification_token.save()

            return Response({"message": "password updated"}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST
            )


@permission_classes([IsAuthenticated])
class ProfileView(APIView):
    def get(self, request):
        user = request.user

        return Response({
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "is_verified": user.is_verified,
            "subscription": get_user_subscription_type(user.email)
        }, status=status.HTTP_200_OK)
