from django.utils import timezone
from loguru import logger
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.authentication import JWTAuthentication


class CustomJWTAuthentication(JWTAuthentication):
    def authenticate(self, request):
        try:
            auth = super().authenticate(request)
        except AuthenticationFailed as original_exception:
            # Customize the exception or raise a custom exception here
            custom_exception = AuthenticationFailed(detail={"error": "invalid token"})
            custom_exception.__cause__ = original_exception
            logger.error("invalid token")
            raise custom_exception
        if auth:
            user, jwt_token = auth
            user.last_login = timezone.now()
            user.save()
            logger.info(f"User Authenticate: '{user.email}' at '{user.last_login}'")

        return auth
