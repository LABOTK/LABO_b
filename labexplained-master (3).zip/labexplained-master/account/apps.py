from django.apps import AppConfig
from backend import get_env_value


class AccountConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "account"

    def ready(self):
        from django.core.management import call_command

        admin_email = get_env_value("ADMIN_EMAIL")
        admin_password = get_env_value("ADMIN_PASSWORD")
        call_command("add_admin_user", email=admin_email, password=admin_password)

