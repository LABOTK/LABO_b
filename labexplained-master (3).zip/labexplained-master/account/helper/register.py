from rest_framework import status
from rest_framework.response import Response

from account.serializers import UserSerializer
from lib.common import get_serializer_error


class AccountRegisterHelper:

    @classmethod
    def create_user(cls, request):
        serializer = UserSerializer(data=request.data)

        if not serializer.is_valid():
            return Response({'error': get_serializer_error(serializer)}, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        email = serializer.data["email"]

        return Response({
            "message": "User created successfully, verify your email!",
            "email": email,
        }, status=status.HTTP_200_OK)
