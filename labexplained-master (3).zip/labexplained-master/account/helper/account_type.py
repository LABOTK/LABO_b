from django.db.models import Max

from lib.choices import PaymentStatusType
from payment.models import UserPayment


def get_user_subscription_type(email):
    latest_payment = UserPayment.objects.filter(
        user=email,
        payment_status=PaymentStatusType.verified
    ).aggregate(Max('created_at'))

    # return 'pro' if latest_payment['created_at__max'] else 'free'
    return 'pro'
