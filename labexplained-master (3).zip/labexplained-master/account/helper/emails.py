

class EmailHelper:

    @classmethod
    def send_forget_password(cls):

        pass
