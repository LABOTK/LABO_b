
import loguru
from django.core.management.base import BaseCommand

from account.models import UserData


class Command(BaseCommand):
    help = 'Adding admin users to database.'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Drop all users and create again')
        parser.add_argument('--email', action='store_true', help='User email required')
        parser.add_argument('--password', action='store_true', help='User password required')

    def handle(self, *args, **options):

        force_load = options['force']
        email = options['email']
        password = options['password']
        loguru.logger.debug(f'Checking Admin: {email}')

        existing_user = UserData.objects.filter(email=email).exists()

        if existing_user and not force_load:
            self.stdout.write(self.style.WARNING('User Admin data already exists. Use --force to update.'))
            return

        if force_load or not existing_user:
            self.stdout.write(f'checking user data info: {email}')
            try:
                user = UserData.objects.get(email=email)
                user.set_password(password)
                user.is_staff = True
                user.is_superuser = True
                user.is_active = True
                user.is_verified = True
                user.save()

            except UserData.DoesNotExist:
                UserData.objects.create_superuser(
                    email=email, password=password, is_superuser=True, is_staff=True, is_active=True, is_verified=True
                )
            self.stdout.write(self.style.SUCCESS(f'{email} - as superuser successfully'))
        else:
            self.stdout.write(self.style.WARNING(f'{email} - adding skipped.'))
