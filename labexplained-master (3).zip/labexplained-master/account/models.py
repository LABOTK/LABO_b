import uuid

from django.contrib.auth.models import AbstractUser, BaseUserManager, Permission
from django.db import models
from django.utils import timezone

from lib.choices import VerificationTokenType
from lib.config import EMAIL_VERIFICATION_EXPIRY_MINUTES


class UserManager(BaseUserManager):
    use_in_migration = True

    def create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError("Email is Required")
        if not password:
            raise ValueError("Password is Required")

        user = self.model(email=self.normalize_email(email), **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser = True")

        return self.create_user(email, password, **extra_fields)


class UserData(AbstractUser):
    username = None
    id = models.UUIDField(default=uuid.uuid4, editable=False)
    email = models.EmailField(primary_key=True)
    is_active = models.BooleanField(default=True)  # TODO: make it false on prod
    is_superuser = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["password"]

    def __str__(self):
        return f"{self.email}"


class VerificationToken(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    token = models.TextField(unique=True)
    user = models.ForeignKey(UserData, on_delete=models.PROTECT)
    type = models.CharField(max_length=255, choices=VerificationTokenType.choices)
    is_verified = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def has_expired(self):
        # check if already used for verification
        if self.is_verified:
            return True
        expiration_time = self.created_at + timezone.timedelta(
            minutes=EMAIL_VERIFICATION_EXPIRY_MINUTES
        )
        return timezone.now() >= expiration_time

    def __str__(self):
        return f"{self.user.email} - {self.type}"

    class Meta:
        ordering = ('created_at',)
