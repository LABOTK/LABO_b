import json
from typing import List

import openai
from loguru import logger

from backend import settings
from lib.common import generate_uuid_token
from lib.config import MAX_AI_RETRIES
from lib.preprocess import PreprocessText

openai.organization = settings.OPENAI_ORG_ID
openai.api_key = settings.OPENAI_API_KEY

QUESTION_FORMATE = "Format: {{'questions': ['question_1', 'question_2', 'question_3']}}"

PODCAST_FORMATE = (
    "in Format ... means continue creating json with same way,"
    " 'type' will be the conversation category, like question introduction, continuity, wrapup or any other "
    "'speaker' will be host guest or multiple guest based on the podcast structure"
    "'text' will be what the said/answer and JSON will be like below:\n"
    "{{'podcast': [{'text': message, 'speaker': 'host', 'type': any}, "
    "{'text': message_1, 'speaker': 'guest|host', type: any}, "
    "{'text': response_1, 'speaker': 'guest|host', type: any}, "
    "{'text': message_2, 'speaker': 'guest|host', type: any}, "
    "{'text': response_2, 'speaker': 'guest|host', type: any}, ................, "
    "{'text': 'message_last', 'speaker': 'guest|host', type: any }, "
    "{'text': 'message_last', 'speaker': 'guest|host', type: any}]}}"
)


def _get_model_response(message: List, model_id: str):
    return openai.ChatCompletion.create(
        model=model_id, max_tokens=1000, temperature=1.2, messages=message
    )


def openai_get_questions(article_text, prompt_dict, model_id, page_num, max_tokens=1000):
    def process_question_prompts() -> List:
        message_list = []

        # 1. question system
        if prompt := prompt_dict.get("question_system"):
            message_list.append(
                {"role": prompt.get("role"), "content": prompt.get("content")}
            )
        else:
            raise ValueError("question_system prompt cannot be empty!")

        # 2. article
        if prompt := prompt_dict.get("article"):
            content = prompt.get("content").replace("#$ARTICLE$#", article_text[0])
            message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("article prompt cannot be empty!")

        # 3. remaining article
        if prompt := prompt_dict.get("remaining_article"):
            for text in article_text[1:2]:
                content = prompt.get("content", "").replace(
                    "#$REMAINING-ARTICLE$#", text
                )
                message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("remaining_article prompt cannot be empty!")

        # 4. questions format
        if prompt := prompt_dict.get("questions_format"):
            if "#$OUTPUT-INSTRUCTIONS$#" in prompt:
                content = prompt.get("content").replace(
                    "#$OUTPUT-INSTRUCTIONS$#", QUESTION_FORMATE
                )
            else:
                content = f"{prompt} {QUESTION_FORMATE}"

            message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("questions_format prompt cannot be empty!")

        if not message_list:
            raise Exception("prompts messages list cannot be empty!")

        return message_list

    # start process
    article_text = PreprocessText.process(article_text, max_tokens)
    messages = process_question_prompts()
    # logger.debug(f"starting {messages} \n page_num: {page_num}")

    for _ in range(MAX_AI_RETRIES):
        try:
            response = _get_model_response(messages, model_id)
            # logger.debug(response.choices)

            # getting response questions content
            raw_questions = response.choices[0].message.content
            # logger.debug(raw_questions)

            parsed_json = json.loads(raw_questions)
            # logger.debug(parsed_json)

            questions = []

            for question in parsed_json["questions"]:
                questions.append({
                    'id': generate_uuid_token(),
                    'question': question,
                    'page_num': page_num,
                })

            return questions, messages
        except Exception as e:
            logger.error(f"Error: while creating ai questions {e}")

    # raise Exception if nothing to return
    raise Exception(f"Error: while creating ai questions, max retries: {MAX_AI_RETRIES}")


def openai_get_script(article_text, prompt_dict, selected_questions, model_id, page_num, max_tokens=70):
    def process_script_prompts() -> List:
        message_list = []

        # 1. question system
        if prompt := prompt_dict.get("script_system"):
            message_list.append(
                {"role": prompt.get("role"), "content": prompt.get("content")}
            )
        else:
            raise ValueError("script_system prompt cannot be empty!")

        # 2. article
        if prompt := prompt_dict.get("article"):
            content = prompt.get("content").replace("#$ARTICLE$#", article_text[0])
            message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("article prompt cannot be empty!")

        # 3. remaining article
        if prompt := prompt_dict.get("remaining_article"):
            for text in article_text[1:2]:
                content = prompt.get("content", "").replace(
                    "#$REMAINING-ARTICLE$#", text
                )
                message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("remaining_article prompt cannot be empty!")

        # 4. selected questions
        if prompt := prompt_dict.get("selected_questions"):
            content = prompt.get("content").replace(
                "#$SELECTED-QUESTIONS$#", selected_questions
            )
            message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("selected prompt cannot be empty!")

        # 5. script format
        if prompt := prompt_dict.get("script_format"):
            if "#$OUTPUT-INSTRUCTIONS$#" in prompt:
                content = prompt.get("content").replace(
                    "#$OUTPUT-INSTRUCTIONS$#", PODCAST_FORMATE
                )
            else:
                content = f"{prompt} {PODCAST_FORMATE}"

            message_list.append({"role": prompt.get("role"), "content": content})
        else:
            raise ValueError("script_format prompt cannot be empty!")

        if not message_list:
            raise Exception("prompts messages list cannot be empty!")

        return message_list

    # start process
    article_text = PreprocessText.process(article_text, max_tokens)
    messages = process_script_prompts()
    # logger.debug(messages)

    for _ in range(MAX_AI_RETRIES):
        try:
            response = _get_model_response(messages, model_id)
            # logger.debug(response.choices)

            raw_script = response.choices[0].message.content
            # logger.debug(raw_script)

            parsed_json = json.JSONDecoder(strict=False).decode(raw_script)
            # logger.debug(parsed_json)

            podcast = []
            selected_keys = ['text', 'speaker', 'type']

            for conv_chunk in parsed_json["podcast"]:
                if all(key in conv_chunk for key in selected_keys):
                    conv_dict = {
                        'id': generate_uuid_token(),
                        'page_num': page_num,
                    }
                    conv_dict.update(conv_chunk)
                    podcast.append(conv_dict)

            return podcast, messages
        except Exception as e:
            logger.error(f"Error: while creating ai script {e}")

    # raise Exception if nothing to return
    raise Exception(f"Error: while creating ai script, max retries: {MAX_AI_RETRIES}")


if __name__ == "__main__":
    # raw_data = "Hello, I'm ahtsham and I'm exploring a engineering working space."
    # prompts_dict = {
    #     "question_system": {
    #         "role": "system",
    #         "content": "Please ensure that the output is valid JSON. As a research assistant, \
    #         you assist in critically analysing shared articles.",
    #     },
    #     "article": {
    #         "role": "user",
    #         "content": "Formulate relevant questions to best understand this article: #$ARTICLE$#",
    #     },
    #     "remaining_article": {
    #         "role": "user",
    #         "content": "Remaining Article: #$REMAINING-ARTICLE$#",
    #     },
    #     "questions_format": {
    #         "role": "user",
    #         "content": "MUST/ONLY VALID JSON OUTPUT as #$OUTPUT-INSTRUCTIONS$#",
    #     },
    # }
    # response_1, messages = openai_get_questions(raw_data, prompts_dict)
    #
    # openai_get_script(raw_data, prompts_dict, " ".join(response_1.values()))

    model_list = openai.Model.list()
    print(model_list)
