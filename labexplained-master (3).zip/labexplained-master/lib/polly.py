import boto3


class PollyTextToSpeech:

    @classmethod
    def process(cls, text, voice_id='Matthew', output_format='mp3'):
        polly_client = boto3.client('polly')
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat=output_format,
            VoiceId=voice_id
        )
        audio_stream = response['AudioStream'].read()
        return audio_stream
