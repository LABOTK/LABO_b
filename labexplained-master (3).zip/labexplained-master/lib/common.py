import os
import tempfile
import uuid
from typing import Dict, List

import PyPDF2
import jwt
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.http import urlsafe_base64_encode
from gtts import gTTS
from loguru import logger
from rest_framework.exceptions import ValidationError

from lib.config import EMAIL_VERIFICATION_EXPIRY_MINUTES, FILE_ACCESS_EXPIRY_MINUTES, MAX_AUDIO_RETRIES
from lib.polly import PollyTextToSpeech
from processor.models import Prompt


def read_pdf_text(pdf_file):
    # Function to read text from a PDF file and return it as a string
    try:
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        pages_length = len(pdf_reader.pages)
        if pages_length > 0:
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            return text.strip()
    except Exception as e:
        logger.error(e)
        raise ValidationError("Error: while extracting the PDF file text.")
    return None


def text_to_audio(text):
    for _ in range(MAX_AUDIO_RETRIES):
        temp_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
        try:
            tts = gTTS(text=text, lang="en")
            tts.save(temp_file.name)
            return temp_file.name
        except Exception as e:
            logger.error(f"Exception occurred: {e}")
            if temp_file:
                temp_file.close()
                os.unlink(temp_file.name)

    # use polly
    audio_stream = PollyTextToSpeech.process(text)

    try:
        temp_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
        temp_file.write(audio_stream)
        return temp_file.name
    except Exception as e:
        logger.error(f"Exception occurred: AWS Polly Failed {e}")

    raise Exception("Failed to generate speech after multiple attempts")


def delete_file_if_exists(file_path):
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except Exception as e:
            logger.error(f"Error while removing file: {e}")
            raise e


def join_questions_with_index(questions: List):
    result_str = ""
    for i, question in enumerate(questions):
        result_str += f"{i + 1}. {question['question']}\n"
    return result_str


def extract_script_as_paragraph(dictionary_list: List[Dict]):
    values = []
    for dictionary in dictionary_list:
        values.append(dictionary.get('text', ''))
    paragraph = " ".join(map(str, values))
    return paragraph


def generate_uuid_token():
    return str(uuid.uuid4())


def generate_jwt_user_token(user_id):
    # Generate a unique JWT token that default expires in 1 hour
    timestamp = timezone.now() + timezone.timedelta(
        minutes=EMAIL_VERIFICATION_EXPIRY_MINUTES
    )
    token = jwt.encode(
        {
            "user_id": str(user_id),
            "expires": timestamp.timestamp(),
            "uuid": generate_uuid_token(),
        },
        settings.SECRET_KEY,
        algorithm="HS256",
    )
    return token


def generate_jwt_file_token(file_path, user_id):
    # Generate a unique JWT token that default expires in 1 hour
    timestamp = timezone.now() + timezone.timedelta(minutes=FILE_ACCESS_EXPIRY_MINUTES)
    token = jwt.encode(
        {
            "file_path": file_path,
            "user_id": str(user_id),
            "expires": timestamp.timestamp(),
            "uuid": generate_uuid_token(),
        },
        settings.SECRET_KEY,
        algorithm="HS256",
    )
    return token


def decode_jwt_token(token):
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
    except Exception as e:
        logger.error(e)
        raise Exception(e)


def send_mail_gmail(subject, message, recipient):
    try:
        send_mail(
            subject,
            message,
            settings.EMAIL_FROM,
            [recipient],
            fail_silently=False,
        )
        return True
    except Exception as e:
        print("Error sending email:", str(e))
        return False


def encode_url_param(param):
    return urlsafe_base64_encode(str(param).encode("utf-8"))


def get_prompts_dict(flow):
    return {
        prompt.type: {
            "role": prompt.role,
            "content": prompt.content,
        }
        for prompt in Prompt.objects.filter(flow=flow)
    }


def get_serializer_error(serializer):
    if serializer and serializer.errors:
        return "\n".join(["\n".join(field_errors) for field, field_errors in serializer.errors.items()])
    return None


def get_media_public_url(token):
    return f"{settings.LAB_BACKEND_URL}/api/media/file/{token}"
