from djchoices import ChoiceItem, DjangoChoices


# ----------------------------------------------------------------
#       SUBSCRIPTION STATUS TYPES
# ----------------------------------------------------------------
class SubscriptionStatusType(DjangoChoices):
    free = ChoiceItem('free', 'Free Plan')
    pro = ChoiceItem('pro', 'Pro Plan')


# ----------------------------------------------------------------
#       LANGUAGE MODEL TYPES
# ----------------------------------------------------------------
class LlmProviderType(DjangoChoices):
    openai = ChoiceItem('openai', 'Open AI')


# ----------------------------------------------------------------
#       VERIFICATION MODEL TYPES
# ----------------------------------------------------------------

class VerificationTokenType(DjangoChoices):
    reset_password = ChoiceItem("reset_password", "Reset Password")
    email_verification = ChoiceItem("email_verification", "Email Verification")


# ----------------------------------------------------------------
#       PROMPT MODEL TYPES
# ----------------------------------------------------------------

class PromptTypeType(DjangoChoices):
    question_system = ChoiceItem("question_system", "Questions Starting Role")
    script_system = ChoiceItem("script_system", "Script Starting Role")
    article = ChoiceItem("article", "Article Text")
    remaining_article = ChoiceItem("remaining_article", "Remaining Article Text")
    questions_format = ChoiceItem("questions_format", "Article Questions Format")
    selected_questions = ChoiceItem("selected_questions", "Selected Script Questions")
    script_format = ChoiceItem("script_format", "Podcast Script Format")


class PromptRoleType(DjangoChoices):
    system = ChoiceItem("system", "System")
    user = ChoiceItem("user", "User")


class PromptFlowType(DjangoChoices):
    question = ChoiceItem("question", "Question Prompt")
    script = ChoiceItem("script", "Script Prompt")


# ----------------------------------------------------------------
#       PAYMENTS MODEL TYPES
# ----------------------------------------------------------------

class PaymentIntervalType(DjangoChoices):
    monthly = ChoiceItem('monthly', 'Monthly')
    yearly = ChoiceItem('yearly', 'Yearly')


class PaymentCurrencyType(DjangoChoices):
    CAD = ChoiceItem('CAD', 'CAD')


class PaymentProviderType(DjangoChoices):
    stripe = ChoiceItem('stripe', 'Stripe')


class PaymentStatusType(DjangoChoices):
    paid = ChoiceItem('paid', 'Paid')
    error = ChoiceItem('error', 'Error')
    unpaid = ChoiceItem('unpaid', 'Unpaid')
    verified = ChoiceItem('verified', 'Verified')


class PaymentSessionStatusType(DjangoChoices):
    open = ChoiceItem('open', 'Open - In Progress')
    error = ChoiceItem('error', 'Error Occurred in Session')
    complete = ChoiceItem('complete', 'Complete; Payment in Progress')
    started = ChoiceItem('started', 'New Session Started')
    expired = ChoiceItem('expired', 'Session Expired')
    cancelled = ChoiceItem('cancelled', 'Session Cancelled')
    successful = ChoiceItem('successful', 'Session Successful')
    verified = ChoiceItem('verified', 'Verified')

# ----------------------------------------------------------------
