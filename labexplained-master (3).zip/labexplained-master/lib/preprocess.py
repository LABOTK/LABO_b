from nltk.tokenize import word_tokenize
# import and download nltk files
import nltk

try:
    nltk.download("punkt")
except Exception as e:
    nltk.data.clear_cache()
    nltk.download("punkt")


class PreprocessText:
    _instance = None

    # Singleton instance
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def process(cls, raw_text, max_tokens):
        def create_sub_paragraphs(words, max_words):
            sub_paragraphs = []
            for i in range(0, len(words), max_words):
                sub_paragraphs.append(" ".join(words[i: i + max_words]))
            return sub_paragraphs

        words = word_tokenize(raw_text)
        # stop_words = set(stopwords.words('english'))
        # return [word.lower() for word in words if word.lower() not in stop_words and word not in string.punctuation]

        return create_sub_paragraphs([word.lower() for word in words], max_tokens)
