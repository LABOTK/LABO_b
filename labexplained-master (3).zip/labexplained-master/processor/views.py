from loguru import logger
from rest_framework import status
from rest_framework.decorators import (
    api_view,
    permission_classes,
)
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from lib.common import (
    join_questions_with_index,
    get_prompts_dict,
)
from lib.open_ai import openai_get_questions, openai_get_script
from processor.helper.process_pdf import PdfProcessHandler
from processor.helper.process_question import QuestionProcessHandler
from processor.models import Podcast
from processor.serializers import PodcastHistorySerializer


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def process_pdf(request):
    try:
        return PdfProcessHandler.create_questions(request)
    except Exception as e:
        logger.error(e)
        return Response(
            {'error': 'Failed to process pdf request!', 'details': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def process_question(request):
    try:
        return QuestionProcessHandler.create_podcast(request)
    except Exception as e:
        logger.error(e)
        return Response(
            {'error': 'Failed to process question request!', 'details': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def process_history(request):
    user = request.user

    # Get page and limit from POST data or set defaults
    page = request.GET.get('page', 1)
    limit = request.GET.get('limit', 20)

    logger.info(f"{user.email} requested for history page {page} and limit {limit}")

    # Define pagination settings
    paginator = PageNumberPagination()
    paginator.page = page
    paginator.page_size = limit

    podcasts = Podcast.objects.filter(user=user)
    paginated_podcasts = paginator.paginate_queryset(podcasts, request)

    serializer = PodcastHistorySerializer(paginated_podcasts, many=True)
    return paginator.get_paginated_response(serializer.data)


@api_view(["POST"])
def test(request):
    question_prompts = get_prompts_dict(flow="question")

    raw_data = request.data.get("article")

    provider_model_id = request.data.get("model_id", "gpt-3.5-turbo-16k")

    questions, question_message = openai_get_questions(
        raw_data, question_prompts,
        model_id=provider_model_id,
        page_num=0
    )

    podcast_prompts = get_prompts_dict(flow="script")
    podcast_data, podcast_message = openai_get_script(
        raw_data, podcast_prompts,
        join_questions_with_index(questions),
        model_id=provider_model_id,
        page_num=0
    )

    return Response(
        {
            "question-prompts": question_message,
            "questions": questions,
            "podcast-prompts": podcast_message,
            "podcast": podcast_data,
        },
        status=status.HTTP_200_OK,
    )
