import concurrent.futures
from loguru import logger
from rest_framework import status
from rest_framework.response import Response

from lib.common import get_prompts_dict, get_serializer_error
from lib.open_ai import openai_get_questions
from media.models import File
from processor.helper.process import ProcessHandler
from processor.models import Podcast
from processor.serializers import ProcessPdfSerializer


class PdfProcessHandler(ProcessHandler):

    @classmethod
    def _process_questions_chunk(cls, chunk, model_id):
        thread_result = []
        for i, item in enumerate(chunk):
            
            questions, _ = openai_get_questions(
                article_text=item.get('text'),
                prompt_dict=get_prompts_dict(flow="question"),
                model_id=model_id,
                page_num=item.get('page_num')
            )

            thread_result.extend(questions)

        return thread_result

    @classmethod
    def _get_questions(cls, textlist, model_id):
        chunk_size = len(textlist) // cls.thread_count
        result_list = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=cls.thread_count) as executor:
            futures = []

            # Divide the data into chunks and create threads
            for i in range(cls.thread_count):
                start_idx = i * chunk_size
                end_idx = start_idx + chunk_size if i < cls.thread_count - 1 else len(textlist)

                if chunk := textlist[start_idx:end_idx]:
                    future = executor.submit(cls._process_questions_chunk, chunk, model_id)
                    futures.append(future)

            # Wait for all futures to complete and collect results
            for future in concurrent.futures.as_completed(futures):
                thread_result = future.result()
                result_list.extend(thread_result)

        return sorted(result_list, key=lambda x: x["page_num"])

    @classmethod
    def create_questions(cls, request):
        user = request.user
        serializer = ProcessPdfSerializer(data=request.data)

        if not serializer.is_valid():
            raise Exception(get_serializer_error(serializer))

        logger.info(f"{user.email}: requesting to process pdf.")

        # check file
        file_token = serializer.validated_data.get("file_token")
        llm_id = serializer.validated_data.get("llm_id")

        # get language model
        language_model = cls._get_llm_model_id(user, llm_id)

        try:
            article_file = File.objects.get(token=file_token)
        except File.DoesNotExist:
            return Response({"error": f"File not fond!"}, status=status.HTTP_400_BAD_REQUEST)

        questions = cls._get_questions(
            textlist=cls._extract_text(file_obj=article_file),
            model_id=language_model.model_id
        )

        # create a podcast
        podcast = Podcast(
            article_file=article_file, user=user,
            ai_questions=questions,
            language_model=language_model
        )
        podcast.save()

        logger.success(f"{user.email}: returning questions.")
        return Response({"podcast_id": podcast.id, "questions": questions}, status=status.HTTP_200_OK)
