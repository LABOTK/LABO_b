import concurrent.futures
import json
import uuid

from django.core.files.storage import default_storage
from loguru import logger
from rest_framework import status
from rest_framework.response import Response

from lib.common import get_serializer_error, get_prompts_dict, join_questions_with_index, \
    extract_script_as_paragraph, text_to_audio, delete_file_if_exists, generate_jwt_file_token, get_media_public_url
from lib.open_ai import openai_get_script
from media.models import File
from processor.helper.process import ProcessHandler
from processor.models import Podcast
from processor.serializers import ProcessQuestionSerializer


class QuestionProcessHandler(ProcessHandler):

    @classmethod
    def _pages_question_data(cls, textlist, questions):
        for page in textlist:
            page['questions'] = [qa for qa in questions if qa["page_num"] == page["page_num"]]

    def _process_podcast_chunk(cls, chunk, model_id):
        thread_result = []
        for i, item in enumerate(chunk):
            podcast_data, _ = openai_get_script(
                article_text=item.get('text'),
                prompt_dict=get_prompts_dict(flow="script"),
                selected_questions=join_questions_with_index(item.get('questions')),
                model_id=model_id,
                page_num=item.get('page_num')
            )

            thread_result.extend(podcast_data)

        return thread_result

    @classmethod
    def _get_podcast(cls, textlist, model_id):
        chunk_size = len(textlist) // cls.thread_count
        result_list = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=cls.thread_count) as executor:
            futures = []

            # Divide the data into chunks and create threads
            for i in range(cls.thread_count):
                start_idx = i * chunk_size
                end_idx = start_idx + chunk_size if i < cls.thread_count - 1 else len(textlist)

                if chunk := textlist[start_idx:end_idx]:
                    future = executor.submit(cls._process_podcast_chunk, chunk, model_id)
                    futures.append(future)

            # Wait for all futures to complete and collect results
            for future in concurrent.futures.as_completed(futures):
                thread_result = future.result()
                result_list.extend(thread_result)

        return sorted(result_list, key=lambda x: x["page_num"])

    @classmethod
    def create_podcast(cls, request):
        user = request.user

        serializer = ProcessQuestionSerializer(data=request.data)
        if not serializer.is_valid():
            raise Exception(get_serializer_error(serializer))

        logger.info(f"{user.email}: requesting to process questions.")

        podcast_id = serializer.validated_data["podcast_id"]
        script_questions = json.loads(serializer.validated_data["questions"])

        try:
            podcast = Podcast.objects.get(id=podcast_id)
        except Podcast.DoesNotExist:
            return Response({"error": "Podcast Request not found!"}, status=404)

        textlist = cls._extract_text(file_obj=podcast.article_file, is_create_embedding=True)
        cls._pages_question_data(textlist, script_questions)

        logger.info(textlist)

        # # get script from OpenAi
        # try:
        #     podcast_data, _ = openai_get_script(
        #         pdf_text,
        #         get_prompts_dict(flow="script"),
        #         join_questions_with_index(script_questions),
        #         model_id=podcast.language_model.model_id
        #     )
        # except Exception as e:
        #     raise Exception(f"Error: while creating ai script, {e}")

        podcast_data = []

        # save updated podcast
        podcast.script_questions = script_questions
        podcast.podcast_script = podcast_data
        podcast.save()

        # create audio
        podcast_text = extract_script_as_paragraph(podcast_data)
        audio_path = text_to_audio(podcast_text)

        # create name of file
        unique_id = str(uuid.uuid4())
        audio_name = f"audio/{user.id}/{unique_id}.mp3"

        # save audio on cloud
        saved_path = default_storage.save(audio_name, open(audio_path, "rb"))

        # delete local audio file
        delete_file_if_exists(audio_path)

        # get token url
        url_token = generate_jwt_file_token(saved_path, user.id)

        response = {
            "audio_url": get_media_public_url(url_token),
            "podcast": podcast_data,
        }

        # Save Record
        audio_file = File.objects.create(token=url_token, file_path=saved_path, user=user)

        # Update Podcast with new audio file:
        podcast.audio_file = audio_file
        podcast.save()
        logger.success(f"{user.email}: returning script")

        # Return the audio file as the response
        return Response(response, status=status.HTTP_200_OK)


