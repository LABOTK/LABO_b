import PyPDF2
from django.core.files.storage import default_storage
from loguru import logger

from embedding.helper.vectordb import VectorDatabaseHelper
from processor.llm_type import get_user_llm_model


class ProcessHandler:

    thread_count = 2

    @classmethod
    def _get_pdf(cls, file_path):

        # file exists check
        if not default_storage.exists(file_path):
            raise Exception("Failed to get PDF file from storage.")

        # open file
        return default_storage.open(file_path)

    @classmethod
    def _create_embedding(cls, file_obj, pdf_reader):
        VectorDatabaseHelper.process_document(file_obj, pdf_reader)

    @classmethod
    def _extract_text(cls, file_obj, is_create_embedding=False):
        pdf_file = cls._get_pdf(file_obj.file_path)
        # extract text from file
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        textlist = []

        for i, page in enumerate(pdf_reader.pages):
            textlist.append(
                {
                    "page_num": (i + 1),
                    "text": (page.extract_text() or '').strip().replace("\n", " "),
                }
            )

        if is_create_embedding:
            cls._create_embedding(file_obj, pdf_reader)

        return textlist

    @classmethod
    def _get_llm_model_id(cls, user, llm_id):
        try:
            return get_user_llm_model(user, llm_id)
        except Exception as e:
            logger.error(f"{e}")
            raise Exception(f"Language Model not available.")
