import json

from django.core.management.base import BaseCommand

from processor.models import LanguageModel

LANGUAGE_MODEL_JSON_FILE_PATH = 'data/language_models_data.json'


class Command(BaseCommand):
    help = 'Load initial language model data from JSON file'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Drop all language model and load data again')

    def handle(self, *args, **options):

        force_load = options['force']

        existing_llms = LanguageModel.objects.exists()

        if existing_llms and not force_load:
            self.stdout.write(self.style.WARNING('Language Models data already exists. Use --force to re-add.'))
            return

        if force_load:
            self.stdout.write('Dropping all existing language model...')
            LanguageModel.objects.all().delete()

        with open(LANGUAGE_MODEL_JSON_FILE_PATH, 'r') as json_file:
            llm_data = json.load(json_file)

        for llm in llm_data:
            LanguageModel.objects.update_or_create(**llm)

        self.stdout.write(self.style.SUCCESS('Language model data loaded successfully'))
