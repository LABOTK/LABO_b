import json

from django.core.management.base import BaseCommand

from processor.models import Prompt

PROMPTS_JSON_FILE_PATH = 'data/prompts_data.json'


class Command(BaseCommand):
    help = 'Load initial prompts data from JSON file'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Drop all prompts and load data again')

    def handle(self, *args, **options):

        force_load = options['force']

        existing_prompts = Prompt.objects.exists()

        if existing_prompts and not force_load:
            self.stdout.write(self.style.WARNING('Prompts data already exists. Use --force to re-add prompts.'))
            return

        if force_load:
            self.stdout.write('Dropping all existing prompts...')
            Prompt.objects.all().delete()

        with open(PROMPTS_JSON_FILE_PATH, 'r') as json_file:
            prompts_data = json.load(json_file)

        for prompt in prompts_data:
            Prompt.objects.update_or_create(**prompt)

        self.stdout.write(self.style.SUCCESS('Prompts data loaded successfully'))
