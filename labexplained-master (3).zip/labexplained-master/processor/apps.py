from django.apps import AppConfig


class ProcessorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "processor"

    def ready(self):
        from django.core.management import call_command
        call_command("makemigrations")
        call_command("migrate")
        call_command("collectstatic", "--noinput")
        call_command("add_language_models")
        call_command("add_prompts")

        # for force update:-> , force=True
        # call_command('add_language_models', force=True)
        # call_command('add_prompts', force=True)
