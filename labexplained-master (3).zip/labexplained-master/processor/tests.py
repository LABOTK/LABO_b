from django.test import TestCase

# Create your tests here.
# tests.py

import os
import uuid
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework_simplejwt.tokens import AccessToken

from account.models import UserData


# tests.py
class ProcessPdfTestCase(APITestCase):
    def setUp(self):
        # Create a test user and get the JWT token for authentication
        self.user = UserData.objects.create_user(
            email="testuser@test.com", password="testpassword"
        )
        self.token = self.get_jwt_token()

    def get_jwt_token(self):
        # Function to get the JWT token for authentication
        access_token = AccessToken.for_user(self.user)
        return str(access_token)

    def test_process_pdf_authenticated(self):
        # Simulate an authenticated POST request to the process_pdf endpoint
        pdf_content = b"This is a test PDF content."
        pdf_file = SimpleUploadedFile(
            "test.pdf", pdf_content, content_type="application/pdf"
        )

        data = {
            "file": pdf_file,
        }

        url = reverse("process_pdf")
        auth_header = f"Bearer {self.token}"
        response = self.client.post(
            url, data, HTTP_AUTHORIZATION=auth_header, format="multipart"
        )

        # Assert the response status code (e.g., 200 for success)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # You can also check the response data if necessary
        # Example: self.assertEqual(response.data, {'message': 'PDF processed successfully.'})

    def test_process_pdf_unauthenticated(self):
        # Simulate an unauthenticated POST request to the process_pdf endpoint
        pdf_content = b"This is a test PDF content."
        pdf_file = SimpleUploadedFile(
            "test.pdf", pdf_content, content_type="application/pdf"
        )

        data = {
            "file": pdf_file,
        }

        url = reverse("process_pdf")
        response = self.client.post(url, data, format="multipart")

        # Assert the response status code (e.g., 401 for unauthorized)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
