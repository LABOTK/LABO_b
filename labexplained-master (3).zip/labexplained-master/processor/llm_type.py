from account.helper.account_type import get_user_subscription_type
from processor.models import LanguageModel


def get_user_llm_model(user, ref_llm_id=None):
    subscription = get_user_subscription_type(user.email)

    language_obj = (LanguageModel.objects.filter(available_for__contains=[subscription]).order_by('-created_at').first())

    if language_obj:
        return language_obj

    raise Exception(f'No Language model found for subscription:{subscription}!')
