import uuid

from django.contrib.postgres.fields import ArrayField
from django.db import models

from account.models import UserData
from lib.choices import (
    PromptFlowType, PromptRoleType, PromptTypeType,
    LlmProviderType, SubscriptionStatusType
)
from media.models import File


# QUESTIONS:
# question_system -> article -> remaining_article -> questions_format: article-questions
# SCRIPT:
# script_system -> article -> remaining_article -> selected_questions -> script_format: podcast-script


class Prompt(models.Model):
    flow = models.CharField(choices=PromptFlowType.choices)
    type = models.CharField(choices=PromptTypeType.choices)
    role = models.CharField(choices=PromptRoleType.choices)
    content = models.TextField()
    sequence = models.PositiveIntegerField()
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.flow} - {self.sequence} - {self.type}"

    class Meta:
        ordering = ["flow", "sequence"]
        unique_together = (("flow", "sequence"), ("flow", "type"))


class LanguageModel(models.Model):
    display_name = models.CharField(unique=True)
    provider = models.CharField(choices=LlmProviderType.choices)
    model_id = models.CharField(unique=True)
    max_token = models.IntegerField()
    request_token = models.IntegerField()
    response_token = models.IntegerField()
    available_for = ArrayField(models.CharField(choices=SubscriptionStatusType.choices))
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.display_name} - {self.provider} - {self.model_id}"

    class Meta:
        ordering = ["provider"]
        unique_together = ("provider", "model_id")


class Podcast(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(UserData, on_delete=models.PROTECT)
    ai_questions = models.JSONField(default=list)
    script_questions = models.JSONField(default=list)
    podcast_script = models.JSONField(default=list)
    language_model = models.ForeignKey(LanguageModel, on_delete=models.PROTECT)
    article_file = models.ForeignKey(File, on_delete=models.PROTECT, related_name='article_podcasts', null=True, blank=True)
    audio_file = models.ForeignKey(File, on_delete=models.PROTECT, related_name='audio_podcasts', null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
