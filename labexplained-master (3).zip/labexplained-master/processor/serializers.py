from rest_framework import serializers

from lib.common import get_media_public_url
from processor.models import Podcast


class ProcessPdfSerializer(serializers.Serializer):
    file_token = serializers.CharField()
    llm_id = serializers.IntegerField()


class ProcessQuestionSerializer(serializers.Serializer):
    podcast_id = serializers.CharField()
    questions = serializers.CharField()


class PodcastSerializer(serializers.ModelSerializer):
    class Meta:
        model = Podcast
        fields = "id"

    def get_id(self, obj):
        return str(obj.id)


class PodcastHistorySerializer(serializers.ModelSerializer):
    audio_file = serializers.SerializerMethodField()
    article_file = serializers.SerializerMethodField()
    created_at = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")

    class Meta:
        model = Podcast
        fields = ['id', 'audio_file', 'article_file', 'created_at']

    def get_audio_file(self, obj):

        # check if audio file exists for podcast
        if audio_file := obj.audio_file:
            audio_url = get_media_public_url(audio_file.token)
            return {'audio_url': audio_url}

        return None

    def get_article_file(self, obj):

        # check if article file exists for podcast
        if article_token := obj.article_file:
            podcast_url = get_media_public_url(article_token.token)
            return {'name': obj.article_file.name, 'podcast_url': podcast_url}

        return None
