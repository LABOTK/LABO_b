from django.urls import path
from processor import views

urlpatterns = [
    path("test", views.test, name="test"),
    path("pdf", views.process_pdf, name="process_pdf"),
    path("question", views.process_question, name="process_question"),
    path("history", views.process_history, name="process_history"),
]
